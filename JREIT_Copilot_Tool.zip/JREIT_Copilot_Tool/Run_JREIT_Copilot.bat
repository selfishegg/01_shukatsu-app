@echo off
chcp 65001 >nul
setlocal EnableExtensions EnableDelayedExpansion

set "BASE=%~dp0"
set "PDFDIR=%BASE%01_PDF"
set "OUTDIR=%BASE%02_Output"
set "PROMPT=%OUTDIR%\Copilot_Request_Current.txt"

if not exist "%PDFDIR%" mkdir "%PDFDIR%"
if not exist "%OUTDIR%" mkdir "%OUTDIR%"

set /a COUNT=0
for %%F in ("%PDFDIR%\*.pdf") do if exist "%%~fF" set /a COUNT+=1

if !COUNT! EQU 0 (
  echo.
  echo 01_PDF フォルダを作成しました。
  echo PDFを入れてから、このバッチをもう一度実行してください。
  echo.
  start "" "%PDFDIR%"
  pause
  exit /b 0
)

copy /y "%BASE%Copilot_Request.txt" "%PROMPT%" >nul
for %%F in ("%PDFDIR%\*.pdf") do >>"%PROMPT%" echo %%~nxF

clip < "%PROMPT%"
start "" "https://m365.cloud.microsoft/chat/"

echo.
echo !COUNT! 件のPDFを検出しました。
echo Copilot用の依頼文をクリップボードへコピーしました。
echo CopilotにPDFを添付し、Ctrl+Vで貼り付けて送信してください。
echo 回答をコピーした後、Save_Copilot_Result.bat を実行してください。
echo.
pause

