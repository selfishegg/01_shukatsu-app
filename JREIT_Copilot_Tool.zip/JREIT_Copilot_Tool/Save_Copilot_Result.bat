@echo off
chcp 65001 >nul
setlocal EnableExtensions

set "BASE=%~dp0"
set "OUTDIR=%BASE%02_Output"
set "OUTFILE=%OUTDIR%\JREIT_transactions_latest.tsv"

if not exist "%OUTDIR%" mkdir "%OUTDIR%"

powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$text = Get-Clipboard -Raw; if ([string]::IsNullOrWhiteSpace($text)) { exit 2 }; $text = $text -replace '(?m)^```(?:tsv|text)?\s*$','' -replace '(?m)^```\s*$',''; [System.IO.File]::WriteAllText($env:OUTFILE, $text.Trim() + [Environment]::NewLine, [System.Text.UTF8Encoding]::new($true))"

if errorlevel 2 (
  echo.
  echo クリップボードが空です。Copilotの回答をコピーしてから再実行してください。
  echo.
  pause
  exit /b 2
)

if errorlevel 1 (
  echo.
  echo 保存に失敗しました。PowerShellの利用制限を確認してください。
  echo 手動の場合はCopilotの回答をメモ帳へ貼り付け、拡張子.tsvで保存してください。
  echo.
  pause
  exit /b 1
)

echo.
echo 保存しました：%OUTFILE%
echo.
start "" "%OUTFILE%"
pause

