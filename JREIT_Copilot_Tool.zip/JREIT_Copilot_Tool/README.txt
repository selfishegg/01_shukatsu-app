J-REIT PDF → Copilot → Excel用TSV ツール

【準備】
このフォルダ全体をOneDrive内へ置いてください。

【使い方】
1. Run_JREIT_Copilot.bat をダブルクリックします。
2. 自動作成された「01_PDF」フォルダへ、J-REITの取得・譲渡PDFを入れます。
3. もう一度 Run_JREIT_Copilot.bat を実行します。
4. Copilotが開き、依頼文がクリップボードへコピーされます。
5. 「01_PDF」のPDFをCopilotへ添付（またはOneDriveから参照）し、Ctrl+Vで依頼文を貼って送信します。
6. Copilotの回答全体をコピーします。
7. Save_Copilot_Result.bat を実行します。
8. 「02_Output\JREIT_transactions_latest.tsv」が作成され、自動的にExcel等で開きます。

【注意】
- Power AutomateとPythonは使用しません。
- Windows標準のコマンドプロンプトとPowerShellのクリップボード機能だけを使います。
- CopilotへのPDF添付と送信だけは手動です。会社のセキュリティ規則に従ってください。
- 出力後は、金額、面積、竣工日、NOIを原文PDFと照合してください。
- Copilotが説明文や ``` を付けた場合、不要な行をExcel上で削除してください。

